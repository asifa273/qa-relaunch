const { test, expect } = require('@playwright/test');
require('dotenv').config();
const { requireEnv } = require('../utils/requireEnv');

const registrationEmail = process.env.SHOP_NEW_REGISTRATION_EMAIL;
const registrationPassword = process.env.SHOP_NEW_REGISTRATION_PASSWORD;

// test.describe.configure({ mode: 'serial' });
const fs = require('fs');
const path = require('path');

// ============================================================================
// Test 1 — Registration: fill the form, confirm the success screen + nav to login
// ============================================================================
test.skip('User Register Form', async ({ browser }) => {
  requireEnv(test, 'SHOP_NEW_REGISTRATION_EMAIL', 'SHOP_NEW_REGISTRATION_PASSWORD');
  const context = await browser.newContext({ viewport: { width: 1600, height: 1000 } });
  const page = await context.newPage();

  await page.goto('https://rahulshettyacademy.com/client/#/auth/register');

  // -- First & Last Name, Email, Phone --

  await page.getByLabel('First Name').fill('Testing');
  await page.getByLabel('Last Name').fill('Asifa');
  await page.getByRole('textbox', { name: 'Email' }).fill(registrationEmail);
  await page.getByRole('textbox', { name: 'enter your number' }).fill('9876543210');

  // -- Occupation -- pick ONE option (cycling every option fires the app's buggy change handler).
  const dropdownOption = page.getByRole('combobox');
  await dropdownOption.selectOption('Scientist');
  await expect(dropdownOption).toHaveValue('4: Scientist');

  // -- Gender --
  await page.getByRole('radio', { name: 'Female' }).click();
  await expect(page.getByRole('radio', { name: 'Female' })).toBeChecked();

  // -- Password / Confirm Password --
  await page.getByRole('textbox', { name: 'Passsword' }).fill(registrationPassword);
  await page.getByRole('textbox', { name: 'Confirm Password' }).fill(registrationPassword);

  // -- Checkbox --
  await page.getByRole('checkbox').check();
  await expect(page.getByRole('checkbox')).toBeChecked();

  // -- Register --
  await page.getByRole('button', { name: 'Register' }).click();

  // The "Registered Successfully" toast is transient; anchor on the stable success screen.
  const successScreen = page.locator('.hero-primary').and(page.getByText('Account Created Successfully'));
  await successScreen.waitFor();
  await expect(page(successScreen)).toBeVisible();
  const loginSuccessMessage = await successScreen.textContent();

  // -- Continue to Login --
  await page.getByRole('button', { name: 'Login' }).click();
  await expect(page).toHaveURL(/\/auth\/login/);
  await context.close();

});

// ============================================================================
// Test 2 — Login, add every product to the cart, cross-verify the count 3 ways
// ============================================================================
test('Login, add every product to the cart, cross-verify the count 3 ways', async ({ browser }) => {
  requireEnv(test, 'SHOP_EMAIL', 'SHOP_PASSWORD');
  const context = await browser.newContext({ viewport: { width: 1600, height: 1000 } });
  const page = await context.newPage();
  await page.goto('https://rahulshettyacademy.com/client/#/auth/login');

  // --- Login ---
  await page.getByRole('textbox', { name: 'Email' }).fill(process.env.SHOP_EMAIL);
  await page.getByRole('textbox', { name: 'enter your passsword' }).fill(process.env.SHOP_PASSWORD);
  await page.getByRole('button', { name: 'Login' }).click();

  // App navigates to the dashboard on successful login (assert instead of a fragile toast).
  // await expect(page).toHaveURL(/dashboard/);

  // --- On the products page ---
  await expect(page.locator('#products')).toBeVisible();
  await page.locator('.card-body b').first().waitFor();

  // List + verify products (clean names come from the <b> tag, not the whole card).
  const names = await page.locator('.card-body b').allTextContents();
  expect(names).toEqual(['ADIDAS ORIGINAL', 'ZARA COAT 3', 'iphone 13 pro']);

  // Also cross-check against the "Showing N results" label.
  const resultText = await page.locator('#res').textContent();
  const shown = parseInt(resultText.match(/\d+/)[0], 10);
  expect(shown).toBe(names.length);

  // --- ONE add loop = single source of truth for `added` ---
  // Filter on .card-body (holds the buttons), NOT .card-body b (just the name text).
  let added = 0;
  for (const name of names) {
    await page.locator('.card-body')
      .filter({ hasText: name })
      .getByRole('button', { name: 'Add To Cart' })
      .click();
    added++;
  }

  // --- Cross-verify #1: header badge count, BEFORE leaving the page ---
  const cartBadge = page.locator('button[routerlink="/dashboard/cart"] label');
  await expect(cartBadge).toHaveText(String(added));   // '3' (toHaveText needs a string)

  // --- Open the cart ---
  // Use the routerlink locator: getByRole('button', {name:'Cart'}) also matches the
  // three "Add To Cart" buttons (substring match) and throws a strict-mode error.
  await page.locator('button[routerlink="/dashboard/cart"]').click();
  await expect(page).toHaveURL(/cart/);
  await expect(page.getByText('My Cart')).toBeVisible();

  // --- Cross-verify #2: one row per cart item ---
  // NOTE: .cartSection resolves to 9 (3 sub-blocks per item), so it's NOT the row.
  // Count the "Buy Now" button instead — exactly one per cart item.
  const cartRows = page.getByRole('button', { name: 'Buy Now' });
  await expect(cartRows).toHaveCount(added);   // 3
  // --Cross Verify the Product name
  const productName = await page.locator('.cartSection h3').allTextContents();
  expect(productName).toEqual(names);



  // ============================================================================
  // Test 3 — Checkout, add every product to the cart, cross-verify the count 3 ways
  // ============================================================================

  // --- Checkout ---
  await page.getByRole('button', { name: 'Checkout' }).click();
  await expect(page).toHaveURL(/order/);
  await expect(page.locator('.payment')).toBeVisible();

  // --- Payment Method ---
  const paymentMethods = await page.locator('.payment__types').allTextContents();
  expect(paymentMethods).toEqual(['Credit CardPaypalSEPAInvoice']);

  // -- Select a payment method (Credit Card) and fill the form --
  await expect(page.getByText('Credit Card Number')).toBeVisible();
  await page.getByRole('textbox').first().fill('4111 1111 1111 1111');
  await page.getByText('Expiry Date').isVisible();
  await page.getByRole('combobox').first().selectOption('12');
  await page.locator('select.ddl').last().selectOption('31');
  await expect(page.getByText('CVV Code ?')).toBeVisible();
  await page.getByRole('textbox').nth(1).fill('123');
  await expect(page.getByText('Name on Card')).toBeVisible();
  await page.getByRole('textbox').nth(2).fill('Testxfirst Testxlast');
  await expect(page.getByText('Apply Coupon').first()).toBeVisible();
  await page.locator('input[name="coupon"]').fill('2026');
  // await page.getByRole('button', { name: 'Apply Coupon' }).click();

  // --- Shipping Information + Place Order ---
  await expect(page.getByText('Shipping Information')).toBeVisible();
  await page.getByRole('textbox').nth(4).fill(process.env.SHOP_EMAIL);
  const country = page.getByPlaceholder('Select Country');
  await country.click();
  await country.pressSequentially('United', { delay: 100 });
  await page.getByText('United States', { exact: true }).waitFor();
  await page.getByText('United States', { exact: true }).click();
  await page.locator('a.action__submit').filter({ hasText: 'Place Order' }).click();

  // --- Cross-verify #3: order summary + thank-you message ---
  await expect(page).toHaveURL(/thanks/);
  await expect(page.locator('h1.hero-primary').and(page.getByText('Thankyou for the order.'))).toBeVisible();
  const productSummary = page.locator('.order-summary');   // ✅ this is a LOCATOR (no await)
  await expect(productSummary.getByText('ADIDAS ORIGINAL')).toBeVisible();
  // or simpler:
  await expect(productSummary).toContainText('ADIDAS ORIGINAL');
  await expect(productSummary.getByText('ADIDAS ORIGINAL')).toBeVisible();
  await expect(productSummary.getByText('ZARA COAT 3')).toBeVisible();
  await expect(productSummary.getByText('iphone 13 pro')).toBeVisible();

  // 1. Grab the invoice numbers shown on the CURRENT PAGE
  const pageInvoiceText = await page.locator('.em-spacer-1, td.content-wrap').first().innerText();
  const invoice = pageInvoiceText.match(/[0-9a-f]{24}/)[0];   // first 24-char id on the page
  await expect(pageInvoiceText).toContain(invoice);        // the 24-char hex ids
  await expect(pageInvoiceText).toContain(invoice);

  // 1. Download the CSV
  const downloadPromise = page.waitForEvent('download');
  await page.getByText('Click To Download Order Details in CSV').click();
  const download = await downloadPromise;
  const csvPath = path.join(__dirname, 'order.csv');
  await download.saveAs(csvPath);
  await download.saveAs('order.csv');

  // --- Read and parse the CSV ---
  const csvContent = fs.readFileSync(csvPath, 'utf8');

  const rows = csvContent
    .split('\n')
    .map(r => r.trim())
    .filter(Boolean)
    .map(r => r.split(','));   // simple split — fine as long as no field contains a comma

  // --- Cross-verify EVERY product name from the Thanks page against the CSV ---
  for (const name of names) {
    const foundInCsv = rows.some(row => row.some(cell => cell.includes(name)));
    expect(foundInCsv, `Product "${name}" not found in CSV`).toBeTruthy();
  }

  // --- Cross-verify the ACTUAL invoice number captured from the Thanks page ---
  const invoiceFoundInCsv = rows.some(row => row.some(cell => cell.includes(invoice)));
  expect(invoiceFoundInCsv, `Invoice "${invoice}" not found in CSV`).toBeTruthy();
  await context.close();

});




